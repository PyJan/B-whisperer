# filename: get_finref_events_corrected.py

from synthetic_api.finref_jakub import get_finref_events
import pandas as pd

# Define the corrected countries and indicators
countries = ['Czech Rep', 'Slovak']
indicators = []

# Get the financial reform events
events_df = get_finref_events(country=countries, indicator=indicators)

# Save the output to a CSV file
events_df.to_csv('./tmp_output.csv', index=False)

# Print the first few rows of the dataframe to verify
print(events_df.head())