# filename: get_deposit_rates.py

from synthetic_api.finref_jakub import get_finref_scores
import pandas as pd

# Define the parameters
country = ["Iraq"]
indicator = ["deposit rate"]
year = [2002]

# Fetch the financial reform scores
df = get_finref_scores(country, indicator, year)

# Save the output to a CSV file
df.to_csv('./tmp_output.csv', index=False)

# Print the head of the dataframe to ensure data is saved
print(df.head())