# filename: fetch_finref_scores.py
from synthetic_api.finref_jakub import get_finref_scores
import pandas as pd

# Define the correct countries and indicators
countries = ['Czech Rep', 'Slovak']
indicators = []  # Empty list to include all indicators

# Fetch data for all years first
data = get_finref_scores(countries, indicators, [])

# Find the most recent year
most_recent_year = data['year'].max()

# Filter data for the most recent year
recent_data = data[data['year'] == most_recent_year]

# Save the data to a CSV file
recent_data.to_csv('./tmp_output.csv', index=False)

# Print the first few rows of the dataframe to ensure the data is not empty
print(recent_data.head())