# filename: get_albania_indicators.py

from synthetic_api.finref_jakub import get_finref_events
import pandas as pd

# Define the parameters
country = ['Albania']
indicator = []

# Fetch the financial reform events
financial_reforms = get_finref_events(country=country, indicator=indicator)

# Display the unique indicators
unique_indicators = financial_reforms['Indicator'].unique()
print(unique_indicators)