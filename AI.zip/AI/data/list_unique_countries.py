# filename: list_unique_countries.py

from synthetic_api.finref_jakub import get_finref_unique_countries

# Fetch the list of unique countries
unique_countries = get_finref_unique_countries()

# Print the unique countries
print(unique_countries)