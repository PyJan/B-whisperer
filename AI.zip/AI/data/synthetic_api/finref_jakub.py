import warnings
from typing import Iterable, List

import pandas as pd



def get_finref_unique_countries() -> List[str]:
    """
    Returns a list of unique countries in the financial reform dataset.

    The function reads the financial reform dataset from a CSV file and extracts
    the unique country names from it.

    Returns:
        List[str]: A list of unique country names.
    """
    finref_dataset = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dataset.csv")
    # Countries
    return list(finref_dataset["country"].unique())
    


def get_finref_scores(country: Iterable, indicator: Iterable, year: Iterable) -> pd.DataFrame:
    """
    Returns financial reform scores for selected indicators, selected countries, and selected years.
    Invalid selections are ignored.

    The function reads the financial reform dataset from a CSV file and filters
    the data based on the provided country, indicator, and year selections. If any
    selection is invalid or not found in the dataset, it is ignored with a warning.

    Args:
        country (Iterable): List of countries to filter by. If empty, all countries are included.
        indicator (Iterable): List of indicators to filter by. If empty, all indicators are included.
        year (Iterable): List of years to filter by. If empty, all years are included.

    Returns:
        pd.DataFrame: Filtered DataFrame containing the financial reform scores for the selected criteria.
    """
    finref_dataset = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dataset.csv")
    # Countries
    countries_in_data = finref_dataset["country"].unique()
    if len(country) == 0:
        country = countries_in_data.copy()
    if len(set(country).difference(countries_in_data)) > 0:
        warnings.warn(f"Input countries {set(country).difference(countries_in_data)} not in the finref dataset. They will be ignored.")
    country = [x for x in country if countries_in_data.__contains__(x)]
    # Indicators
    indicators_in_data = finref_dataset.columns.difference(["country", "ifs", "code", "year"])
    if len(indicator) == 0:
        indicator = indicators_in_data.copy()
    if len(set(indicator).difference(indicators_in_data)) > 0:
        warnings.warn(f"Input indicators {set(indicator).difference(indicators_in_data)} not in the finref dataset. They will be ignored.")
    indicator = [x for x in indicator if indicators_in_data.__contains__(x)]
    # Years
    years_in_data = finref_dataset["year"].unique()
    if len(year) == 0:
        year = years_in_data.copy()
    if len(set(year).difference(years_in_data)) > 0:
        warnings.warn(f"Input indicators {set(year).difference(years_in_data)} not in the finref dataset. They will be ignored.")
    year = [x for x in year if years_in_data.__contains__(x)]

    return finref_dataset.loc[finref_dataset["country"].isin(country) & finref_dataset["year"].isin(year), ["country", "year"] + indicator]


def get_finref_events(country: Iterable, indicator: Iterable) -> pd.DataFrame:
    """
    Returns financial reform events for selected indicators and selected countries.
    Invalid selections are ignored.

    The function reads the financial reform chronology and dictionary datasets from CSV files,
    and merges them to create a comprehensive dataset of financial reform events. It filters
    the data based on the provided country and indicator selections. If any selection is
    invalid or not found in the dataset, it is ignored with a warning.

    Args:
        country (Iterable): List of countries to filter by. If empty, all countries are included.
        indicator (Iterable): List of indicators to filter by. If empty, all indicators are included.

    Returns:
        pd.DataFrame: Filtered DataFrame containing the financial reform events for the selected criteria.
    """
    finref_chronology = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_chronology.csv")
    finref_dictionary = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dictionary.csv")
    # Preparing the data
    finref_chronology["Policy"] = finref_chronology["Policy"].ffill()
    finref_chronology.rename(columns={"Description": "Event Description"}, inplace=True)
    finref_dictionary.rename(columns={"Variable Name": "Indicator", "Description": "Indicator Description"}, inplace=True)
    finref_chronology = finref_chronology.merge(right=finref_dictionary, how="left", left_on=["Policy"], right_on=["Indicator Description"])
    finref_chronology.sort_values(by=["Country", "Indicator", "Year"], axis=0, inplace=True)
    finref_chronology["Value"] = pd.to_numeric(finref_chronology["Value"], errors="coerce")
    finref_chronology["Value Previous"] = finref_chronology.groupby(["Country", "Indicator"])["Value"].shift()
    finref_chronology["Value Start"] = finref_chronology.groupby(["Country", "Indicator"])["Value"].transform("first")
    finref_chronology.loc[finref_chronology["Value Previous"].isna(), "Value Previous"] = finref_chronology.loc[finref_chronology["Value Previous"].isna(), "Value Start"]
    finref_chronology["Value Difference"] = finref_chronology["Value"] - finref_chronology["Value Previous"]
    # Countries
    countries_in_data = finref_chronology["Country"].unique()
    if len(country) == 0:
        country = countries_in_data.copy()
    if len(set(country).difference(countries_in_data)) > 0:
        warnings.warn(f"Input countries {set(country).difference(countries_in_data)} not in the finref chronology. They will be ignored.")
    country = [x for x in country if countries_in_data.__contains__(x)]
    # Indicators
    indicators_in_data = finref_chronology["Indicator"].unique()
    if len(indicator) == 0:
        indicator = indicators_in_data.copy()
    if len(set(indicator).difference(indicators_in_data)) > 0:
        warnings.warn(f"Input indicators {set(indicator).difference(indicators_in_data)} not in the finref chronology. They will be ignored.")
    indicator = [x for x in indicator if indicators_in_data.__contains__(x)]

    return finref_chronology.loc[finref_chronology["Country"].isin(country) & finref_chronology["Indicator"].isin(indicator), ]
