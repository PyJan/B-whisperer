import pandas as pd  
from typing import Optional  
  
def get_policies_by_country_and_year(country: str, year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and year.  
  
    Args:  
        country (str): The country to filter by.  
        year (int): The year to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and year.  
  
    Example:  
        get_policies_by_country_and_year("Belgium", 1998)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df['year'] == year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_countries_with_policy(policy: str) -> Optional[pd.DataFrame]:  
    """  
    Get countries that have a specific policy.  
  
    Args:  
        policy (str): The policy to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the countries with the specified policy.  
  
    Example:  
        get_countries_with_policy("creditcont2013")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df[policy].notna()]  
        return result[['country']].drop_duplicates() if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_years_with_policy(policy: str) -> Optional[pd.DataFrame]:  
    """  
    Get years that have a specific policy.  
  
    Args:  
        policy (str): The policy to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the years with the specified policy.  
  
    Example:  
        get_years_with_policy("creditcont2013")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df[policy].notna()]  
        return result[['year']].drop_duplicates() if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_year(year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific year.  
  
    Args:  
        year (int): The year to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified year.  
  
    Example:  
        get_policies_by_year(1998)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df['year'] == year]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country(country: str) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country.  
  
    Args:  
        country (str): The country to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country.  
  
    Example:  
        get_policies_by_country("Belgium")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df['country'] == country]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_countries_with_year(year: int) -> Optional[pd.DataFrame]:  
    """  
    Get countries that have policies in a specific year.  
  
    Args:  
        year (int): The year to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the countries with policies in the specified year.  
  
    Example:  
        get_countries_with_year(1998)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df['year'] == year]  
        return result[['country']].drop_duplicates() if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_description(description: str) -> Optional[pd.DataFrame]:  
    """  
    Get policies that match a specific description.  
  
    Args:  
        description (str): The description to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies with the specified description.  
  
    Example:  
        get_policies_by_description("Credit controls and reserve requirements -2013 (0-3)")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dictionary.csv")
        result = df[df['Description'].str.contains(description, na=False)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_unique_policies() -> Optional[pd.DataFrame]:  
    """  
    Get unique policies in the dataset.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the unique policies.  
  
    Example:  
        get_unique_policies()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df.drop(columns=['country', 'ifs', 'code', 'year']).drop_duplicates()  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_unique_countries() -> Optional[pd.DataFrame]:  
    """  
    Get unique countries in the dataset.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the unique countries.  
  
    Example:  
        get_unique_countries()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[['country']].drop_duplicates()  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_unique_years() -> Optional[pd.DataFrame]:  
    """  
    Get unique years in the dataset.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the unique years.  
  
    Example:  
        get_unique_years()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[['year']].drop_duplicates()  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_value(value: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies that have a specific value.  
  
    Args:  
        value (int): The value to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies with the specified value.  
  
    Example:  
        get_policies_by_value(2)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[df.isin([value]).any(axis=1)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_and_policy(country: str, policy: str) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and policy.  
  
    Args:  
        country (str): The country to filter by.  
        policy (str): The policy to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and policy.  
  
    Example:  
        get_policies_by_country_and_policy("Belgium", "creditcont2013")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df[policy].notna())]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_and_value(country: str, value: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and value.  
  
    Args:  
        country (str): The country to filter by.  
        value (int): The value to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and value.  
  
    Example:  
        get_policies_by_country_and_value("Belgium", 1)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df.isin([value]).any(axis=1))]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_policy_and_value(policy: str, value: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific policy and value.  
  
    Args:  
        policy (str): The policy to filter by.  
        value (int): The value to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified policy and value.  
  
    Example:  
        get_policies_by_policy_and_value("creditcont2013", 1)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df[policy] == value)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_and_description(country: str, description: str) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and description.  
  
    Args:  
        country (str): The country to filter by.  
        description (str): The description to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and description.  
  
    Example:  
        get_policies_by_country_and_description("Belgium", "Credit controls and reserve requirements -2013 (0-3)")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        dict_df = pd.read_csv("data/hackathon_data/finref_dictionary.csv")  
        policy_columns = dict_df[dict_df['Description'].str.contains(description, na=False)]['Variable Name']  
        result = df[(df['country'] == country) & (df[policy_columns].notna().any(axis=1))]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_policy_and_description(policy: str, description: str) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific policy and description.  
  
    Args:  
        policy (str): The policy to filter by.  
        description (str): The description to filter by.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified policy and description.  
  
    Example:  
        get_policies_by_policy_and_description("creditcont2013", "Credit controls and reserve requirements -2013 (0-3)")  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        dict_df = pd.read_csv("data/hackathon_data/finref_dictionary.csv")  
        policy_columns = dict_df[dict_df['Description'].str.contains(description, na=False)]['Variable Name']  
        result = df[(df[policy].notna()) & (df[policy_columns].notna().any(axis=1))]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_and_year_range(country: str, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country within a year range.  
  
    Args:  
        country (str): The country to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country within the year range.  
  
    Example:  
        get_policies_by_country_and_year_range("Belgium", 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_policy_and_year_range(policy: str, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific policy within a year range.  
  
    Args:  
        policy (str): The policy to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified policy within the year range.  
  
    Example:  
        get_policies_by_policy_and_year_range("creditcont2013", 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df[policy].notna()) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_value_and_year_range(value: int, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific value within a year range.  
  
    Args:  
        value (int): The value to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified value within the year range.  
  
    Example:  
        get_policies_by_value_and_year_range(2, 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df.isin([value]).any(axis=1)) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_policy_and_year_range(country: str, policy: str, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and policy within a year range.  
  
    Args:  
        country (str): The country to filter by.  
        policy (str): The policy to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and policy within the year range.  
  
    Example:  
        get_policies_by_country_policy_and_year_range("Belgium", "creditcont2013", 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df[policy].notna()) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_country_value_and_year_range(country: str, value: int, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific country and value within a year range.  
  
    Args:  
        country (str): The country to filter by.  
        value (int): The value to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified country and value within the year range.  
  
    Example:  
        get_policies_by_country_value_and_year_range("Belgium", 1, 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df['country'] == country) & (df.isin([value]).any(axis=1)) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None  
  
def get_policies_by_policy_value_and_year_range(policy: str, value: int, start_year: int, end_year: int) -> Optional[pd.DataFrame]:  
    """  
    Get policies for a specific policy and value within a year range.  
  
    Args:  
        policy (str): The policy to filter by.  
        value (int): The value to filter by.  
        start_year (int): The start year of the range.  
        end_year (int): The end year of the range.  
  
    Returns:  
        Optional[pd.DataFrame]: DataFrame containing the policies for the specified policy and value within the year range.  
  
    Example:  
        get_policies_by_policy_value_and_year_range("creditcont2013", 1, 1990, 2000)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
        result = df[(df[policy] == value) & (df['year'] >= start_year) & (df['year'] <= end_year)]  
        return result if not result.empty else None  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return None