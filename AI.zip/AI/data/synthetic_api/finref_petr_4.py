import pandas as pd

def get_all_events (country:str, start_year: int, end_year:int):
    '''Find all policy changes for selected country and given time span'''
    data=pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
    data["Policy"] = data["Policy"].ffill()
    if country not in data['Country'].drop_duplicates().to_list():
        return 'Country not included'
    if start_year > int(max(data['Year'].drop_duplicates().to_list())) or end_year < int(min(data['Year'].drop_duplicates().to_list())):
        return 'Year not included'
    data = data[data['Country'] == country]
    data = data[data['Year'] >= str(start_year)]
    data = data[data['Year'] <= str(end_year)]
    return data[['Year', 'Policy', 'Value', 'Description']].set_index('Year')

if __name__ == '__main__':
    print(get_all_events('Albania',2005, end_year= 2020))