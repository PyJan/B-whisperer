import pandas as pd

def select_x_top(x: int):
    data=pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
    data[:x]
    return data.to_csv()

if __name__ == '__main__':
    print(select_x_top(5))