import warnings
from typing import Iterable

import pandas as pd

def get_finref_unique_countries():
    """Returns financial reform scores for selected indicators, selected countries, and selected years. Invalid selections are ignored."""
    # Loading the data
    finref_dataset = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dataset.csv")
    # Countries
    return list(finref_dataset["country"].unique())
    

countries_list = get_finref_unique_countries()