import pandas as pd

def compute_lending_deposit_diff (country:str, year: int):
    '''Calculates difference of lending and deposit rate for given year and country'''
    data=pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
    if country not in data['country'].drop_duplicates().to_list():
        return 'Country not included'
    if year not in data['year'].drop_duplicates().to_list():
        return 'Year not included'
    data = data[data['country'] == country]
    data = data[data['year'] == year]
    data['dif'] = data['lendingrate'] - data['depositrate']
    return data['dif'].values[0]

if __name__ == '__main__':
    print(compute_lending_deposit_diff('Albania',2005))