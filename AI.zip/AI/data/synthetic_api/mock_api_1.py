def mock_company_results(company, year):
    return 84844544.5