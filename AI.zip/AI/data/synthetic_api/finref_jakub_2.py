import warnings
from typing import Iterable

import pandas as pd

def get_finref_events(country: Iterable, indicator: Iterable):
    """Returs financial reform events for selected for selected indicators and selected countries. Invalid selections are ignored."""
    # Loading the data
    finref_chronology = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_chronology.csv")
    finref_dictionary = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dictionary.csv")
    # Preparing the data
    finref_chronology["Policy"] = finref_chronology["Policy"].ffill()
    finref_chronology.rename(columns={"Description": "Event Description"}, inplace=True)
    finref_dictionary.rename(columns={"Variable Name": "Indicator", "Description": "Indicator Description"}, inplace=True)
    finref_chronology = finref_chronology.merge(right=finref_dictionary, how="left", left_on=["Policy"], right_on=["Indicator Description"])
    finref_chronology.sort_values(by=["Country", "Indicator", "Year"], axis=0, inplace=True)
    finref_chronology["Value"] = pd.to_numeric(finref_chronology["Value"], errors="coerce")
    finref_chronology["Value Previous"] = finref_chronology.groupby(["Country", "Indicator"])["Value"].shift()
    finref_chronology["Value Start"] = finref_chronology.groupby(["Country", "Indicator"])["Value"].transform("first")
    finref_chronology.loc[finref_chronology["Value Previous"].isna(), "Value Previous"] = finref_chronology.loc[finref_chronology["Value Previous"].isna(), "Value Start"]
    finref_chronology["Value Difference"] = finref_chronology["Value"] - finref_chronology["Value Previous"]
    # Countries
    countries_in_data = finref_chronology["Country"].unique()
    if len(country) == 0:
        country = countries_in_data.copy()
    if len(set(country).difference(countries_in_data)) > 0:
        warnings.warn(f"Input countries {set(country).difference(countries_in_data)} not in the finref chronology. They will be ignored.")
    country = [x for x in country if countries_in_data.__contains__(x)]
    # Indicators
    indicators_in_data = finref_chronology["Indicator"].unique()
    if len(indicator) == 0:
        indicator = indicators_in_data.copy()
    if len(set(indicator).difference(indicators_in_data)) > 0:
        warnings.warn(f"Input indicators {set(indicator).difference(indicators_in_data)} not in the finref chronology. They will be ignored.")
    indicator = [x for x in indicator if indicators_in_data.__contains__(x)]

    return finref_chronology.loc[finref_chronology["Country"].isin(country) & finref_chronology["Indicator"].isin(indicator), ]

if __name__ == '__main__':
    # Example call
    print(get_finref_events(country=['Albania', 'B', 'Uzbekistan'], indicator=['RR', 'C']))
