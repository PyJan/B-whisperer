import pandas as pd  
from typing import List
  
def get_unique_countries() -> pd.DataFrame:  
    """  
    Get a list of unique countries in the dataset.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing unique countries.  
      
    Example:  
        get_unique_countries()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        unique_countries = df['Country'].unique()  
        return pd.DataFrame(unique_countries, columns=['Country'])  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_country(country: str) -> pd.DataFrame:  
    """  
    Get all policies for a specific country.  
  
    Args:  
        country (str): The name of the country.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies for the specified country.  
      
    Example:  
        get_policies_by_country('Switzerland')  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        country_policies = df[df['Country'] == country]  
        return country_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_year(year: int) -> pd.DataFrame:  
    """  
    Get all policies for a specific year.  
  
    Args:  
        year (int): The year to filter policies.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies for the specified year.  
      
    Example:  
        get_policies_by_year(2013)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        year_policies = df[df['Year'] == year]  
        return year_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_country_and_year(country: str, year: int) -> pd.DataFrame:  
    """  
    Get all policies for a specific country and year.  
  
    Args:  
        country (str): The name of the country.  
        year (int): The year to filter policies.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies for the specified country and year.  
      
    Example:  
        get_policies_by_country_and_year('Switzerland', 1973)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        country_year_policies = df[(df['Country'] == country) & (df['Year'] == year)]  
        return country_year_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_policy_type(policy_type: str) -> pd.DataFrame:  
    """  
    Get all policies of a specific type.  
  
    Args:  
        policy_type (str): The type of policy.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies of the specified type.  
      
    Example:  
        get_policies_by_policy_type('Banking supervision/supervisory power (0-2)')  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        policy_type_policies = df[df['Policy'] == policy_type]  
        return policy_type_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_value(value: int) -> pd.DataFrame:  
    """  
    Get all policies with a specific value.  
  
    Args:  
        value (int): The value of the policy.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with the specified value.  
      
    Example:  
        get_policies_by_value(2)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        value_policies = df[df['Value'] == value]  
        return value_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_by_description_keyword(keyword: str) -> pd.DataFrame:  
    """  
    Get all policies containing a specific keyword in the description.  
  
    Args:  
        keyword (str): The keyword to search in the description.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with the specified keyword in the description.  
      
    Example:  
        get_policies_by_description_keyword('liberalization')  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        keyword_policies = df[df['Description'].str.contains(keyword, na=False)]  
        return keyword_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_countries_with_policy(policy_type: str) -> pd.DataFrame:  
    """  
    Get a list of countries that have a specific policy type.  
  
    Args:  
        policy_type (str): The type of policy.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing countries with the specified policy type.  
      
    Example:  
        get_countries_with_policy('Reserve requirements (0-2)')  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        countries_with_policy = df[df['Policy'] == policy_type]['Country'].unique()  
        return pd.DataFrame(countries_with_policy, columns=['Country'])  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_years_with_policy(policy_type: str) -> pd.DataFrame:  
    """  
    Get a list of years that have a specific policy type.  
  
    Args:  
        policy_type (str): The type of policy.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing years with the specified policy type.  
      
    Example:  
        get_years_with_policy('Reserve requirements (0-2)')  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        years_with_policy = df[df['Policy'] == policy_type]['Year'].unique()  
        return pd.DataFrame(years_with_policy, columns=['Year'])  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policy_counts_by_country() -> pd.DataFrame:  
    """  
    Get the count of policies for each country.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the count of policies for each country.  
      
    Example:  
        get_policy_counts_by_country()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        policy_counts = df['Country'].value_counts().reset_index()  
        policy_counts.columns = ['Country', 'PolicyCount']  
        return policy_counts  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policy_counts_by_year() -> pd.DataFrame:  
    """  
    Get the count of policies for each year.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the count of policies for each year.  
      
    Example:  
        get_policy_counts_by_year()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        policy_counts = df['Year'].value_counts().reset_index()  
        policy_counts.columns = ['Year', 'PolicyCount']  
        return policy_counts  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policy_counts_by_policy_type() -> pd.DataFrame:  
    """  
    Get the count of policies for each policy type.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the count of policies for each policy type.  
      
    Example:  
        get_policy_counts_by_policy_type()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        policy_counts = df['Policy'].value_counts().reset_index()  
        policy_counts.columns = ['Policy', 'PolicyCount']  
        return policy_counts  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policy_counts_by_value() -> pd.DataFrame:  
    """  
    Get the count of policies for each value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the count of policies for each value.  
      
    Example:  
        get_policy_counts_by_value()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        policy_counts = df['Value'].value_counts().reset_index()  
        policy_counts.columns = ['Value', 'PolicyCount']  
        return policy_counts  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_with_highest_value() -> pd.DataFrame:  
    """  
    Get policies with the highest value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with the highest value.  
      
    Example:  
        get_policies_with_highest_value()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        max_value = df['Value'].max()  
        highest_value_policies = df[df['Value'] == max_value]  
        return highest_value_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_with_lowest_value() -> pd.DataFrame:  
    """  
    Get policies with the lowest value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with the lowest value.  
      
    Example:  
        get_policies_with_lowest_value()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        min_value = df['Value'].min()  
        lowest_value_policies = df[df['Value'] == min_value]  
        return lowest_value_policies  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_average_policy_value_by_country() -> pd.DataFrame:  
    """  
    Get the average policy value for each country.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the average policy value for each country.  
      
    Example:  
        get_average_policy_value_by_country()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        avg_policy_value = df.groupby('Country')['Value'].mean().reset_index()  
        avg_policy_value.columns = ['Country', 'AveragePolicyValue']  
        return avg_policy_value  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_average_policy_value_by_year() -> pd.DataFrame:  
    """  
    Get the average policy value for each year.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the average policy value for each year.  
      
    Example:  
        get_average_policy_value_by_year()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        avg_policy_value = df.groupby('Year')['Value'].mean().reset_index()  
        avg_policy_value.columns = ['Year', 'AveragePolicyValue']  
        return avg_policy_value  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_average_policy_value_by_policy_type() -> pd.DataFrame:  
    """  
    Get the average policy value for each policy type.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing the average policy value for each policy type.  
      
    Example:  
        get_average_policy_value_by_policy_type()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        avg_policy_value = df.groupby('Policy')['Value'].mean().reset_index()  
        avg_policy_value.columns = ['Policy', 'AveragePolicyValue']  
        return avg_policy_value  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_with_value_above_threshold(threshold: int) -> pd.DataFrame:  
    """  
    Get policies with a value above a specified threshold.  
  
    Args:  
        threshold (int): The threshold value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with a value above the specified threshold.  
      
    Example:  
        get_policies_with_value_above_threshold(1)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        policies_above_threshold = df[df['Value'] > threshold]  
        return policies_above_threshold  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_with_value_below_threshold(threshold: int) -> pd.DataFrame:  
    """  
    Get policies with a value below a specified threshold.  
  
    Args:  
        threshold (int): The threshold value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with a value below the specified threshold.  
      
    Example:  
        get_policies_with_value_below_threshold(1)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        policies_below_threshold = df[df['Value'] < threshold]  
        return policies_below_threshold  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_policies_with_value_between(min_value: int, max_value: int) -> pd.DataFrame:  
    """  
    Get policies with a value between a specified range.  
  
    Args:  
        min_value (int): The minimum value of the range.  
        max_value (int): The maximum value of the range.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing policies with a value between the specified range.  
      
    Example:  
        get_policies_with_value_between(1, 2)  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        policies_between = df[(df['Value'] >= min_value) & (df['Value'] <= max_value)]  
        return policies_between  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_countries_with_highest_average_policy_value() -> pd.DataFrame:  
    """  
    Get countries with the highest average policy value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing countries with the highest average policy value.  
      
    Example:  
        get_countries_with_highest_average_policy_value()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        avg_policy_value = df.groupby('Country')['Value'].mean().reset_index()  
        max_avg_value = avg_policy_value['Value'].max()  
        countries_with_highest_avg = avg_policy_value[avg_policy_value['Value'] == max_avg_value]  
        return countries_with_highest_avg  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  
  
def get_countries_with_lowest_average_policy_value() -> pd.DataFrame:  
    """  
    Get countries with the lowest average policy value.  
  
    Returns:  
        pd.DataFrame: A DataFrame containing countries with the lowest average policy value.  
      
    Example:  
        get_countries_with_lowest_average_policy_value()  
    """  
    try:  
        df = pd.read_csv(r"C:\AI\data\hackathon_data\finref_chronology.csv")
        df['Value'] = pd.to_numeric(df['Value'], errors='coerce')  
        avg_policy_value = df.groupby('Country')['Value'].mean().reset_index()  
        min_avg_value = avg_policy_value['Value'].min()  
        countries_with_lowest_avg = avg_policy_value[avg_policy_value['Value'] == min_avg_value]  
        return countries_with_lowest_avg  
    except Exception as e:  
        print(f"An error occurred: {e}")  
        return pd.DataFrame()  