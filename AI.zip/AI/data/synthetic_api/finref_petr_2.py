import pandas as pd

def get_lending_rate (country:str, year: int):
    '''Returns lending rate for given year and country'''
    data=pd.read_csv(r"C:\AI\data\hackathon_data\finref_dataset.csv")
    if country not in data['country'].drop_duplicates().to_list():
        return 'Country not included'
    if year not in data['year'].drop_duplicates().to_list():
        return 'Year not included'
    data = data[data['country'] == country]
    data = data[data['year'] == year]
    return data['lendingrate'].values[0]

if __name__ == '__main__':
    print(get_lending_rate('Albania',2005))