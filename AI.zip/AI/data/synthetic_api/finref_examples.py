from data.synthetic_api.finref_jakub import get_finref_events
from data.synthetic_api.finref_jakub import get_finref_scores
from data.synthetic_api.finref_jakub import get_finref_unique_countries


if __name__ == '__main__':
    # Returns financial reform scores for selected indicators, selected countries, and selected years. Invalid selections are ignored
    # def get_finref_scores(country: Iterable, indicator: Iterable, year: Iterable) -> pd.DataFrame:
    data = get_finref_scores(country=['Albania', 'B', 'Uzbekistan'], indicator=['creditcont2013', 'intrate2013', 'C'], year=[1991, 2012, 2013, 2014])

    # Returns financial reform events for selected for selected indicators and selected countries. Invalid selections are ignored
    # def get_finref_events(country: Iterable, indicator: Iterable) -> pd.DataFrame:
    data = get_finref_events(country=['Albania', 'B', 'Uzbekistan'], indicator=['RR', 'C'])

    # Returns a list of unique countries in the financial reform dataset.
    # def get_finref_unique_countries() -> List[str]:
    countries_list = get_finref_unique_countries()
