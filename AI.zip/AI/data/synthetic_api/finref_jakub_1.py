import warnings
from typing import Iterable

import pandas as pd

def get_finref_scores(country: Iterable, indicator: Iterable, year: Iterable):
    """Returns financial reform scores for selected indicators, selected countries, and selected years. Invalid selections are ignored."""
    # Loading the data
    finref_dataset = pd.read_csv(filepath_or_buffer=r"C:\AI\data\hackathon_data\finref_dataset.csv")
    # Countries
    countries_in_data = finref_dataset["country"].unique()
    if len(country) == 0:
        country = countries_in_data.copy()
    if len(set(country).difference(countries_in_data)) > 0:
        warnings.warn(f"Input countries {set(country).difference(countries_in_data)} not in the finref dataset. They will be ignored.")
    country = [x for x in country if countries_in_data.__contains__(x)]
    # Indicators
    indicators_in_data = finref_dataset.columns.difference(["country", "ifs", "code", "year"])
    if len(indicator) == 0:
        indicator = indicators_in_data.copy()
    if len(set(indicator).difference(indicators_in_data)) > 0:
        warnings.warn(f"Input indicators {set(indicator).difference(indicators_in_data)} not in the finref dataset. They will be ignored.")
    indicator = [x for x in indicator if indicators_in_data.__contains__(x)]
    # Years
    years_in_data = finref_dataset["year"].unique()
    if len(year) == 0:
        year = years_in_data.copy()
    if len(set(year).difference(years_in_data)) > 0:
        warnings.warn(f"Input indicators {set(year).difference(years_in_data)} not in the finref dataset. They will be ignored.")
    year = [x for x in year if years_in_data.__contains__(x)]

    return finref_dataset.loc[finref_dataset["country"].isin(country) & finref_dataset["year"].isin(year), ["country", "year"] + indicator]

# Example call
# get_finref_scores(country=['Albania', 'B', 'Uzbekistan'], indicator=['creditcont2013', 'intrate2013', 'C'], year=[1991, 2012, 2013, 2014])