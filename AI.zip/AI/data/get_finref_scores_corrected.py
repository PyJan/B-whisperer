# filename: get_finref_scores_corrected.py

from synthetic_api.finref_jakub import get_finref_scores

# Define the correct country names, indicators, and years of interest
countries = ["Czech Rep", "Slovak"]
indicators = []  # Empty list means all indicators
years = []  # Empty list means all years

# Get the financial reform scores
scores_df = get_finref_scores(country=countries, indicator=indicators, year=years)

# Save the output to a CSV file
output_path = './tmp_output.csv'
scores_df.to_csv(output_path, index=False)

# Print the first few rows of the dataframe to verify the output
print(scores_df.head())