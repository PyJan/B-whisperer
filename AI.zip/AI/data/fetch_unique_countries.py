# filename: fetch_unique_countries.py
from synthetic_api.finref_jakub import get_finref_unique_countries

# Fetch the unique countries
unique_countries = get_finref_unique_countries()

# Print the list of unique countries
print(unique_countries)