
class Examples:
    examples_dict = {'I want to sum A and B':
                         'sum(A,B)'
                }