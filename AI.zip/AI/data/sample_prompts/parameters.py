
class Parameters():
    parameters_dict = {"temperature": 0.2,
                       "top_p": 0.95,
                       "max_tokens": 800}
