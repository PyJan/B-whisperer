# filename: get_financial_reforms_albania_rr.py

from synthetic_api.finref_jakub import get_finref_events
import pandas as pd

# Define the parameters
country = ['Albania']
indicator = ['RR']

# Fetch the financial reform events
financial_reforms = get_finref_events(country=country, indicator=indicator)

# Save the output to a CSV file
financial_reforms.to_csv('./tmp_output.csv', index=False)

# Print the first few rows of the dataframe to ensure data is fetched
print(financial_reforms.head())