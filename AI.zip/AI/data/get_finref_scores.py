# filename: get_finref_scores.py

from synthetic_api.finref_jakub import get_finref_scores, get_finref_unique_countries
import pandas as pd

# Define the correct country names based on the unique countries list
countries = ["Czech Rep", "Slovak"]
indicators = []  # Empty list to include all indicators

# Get the most recent year from the dataset
all_years = get_finref_scores(country=countries, indicator=indicators, year=[]).year.unique()
most_recent_year = [max(all_years)] if all_years.size > 0 else []

# Get the finref scores for the most recent year
if most_recent_year:
    finref_scores = get_finref_scores(country=countries, indicator=indicators, year=most_recent_year)

    # Save the output to a CSV file
    output_file = './tmp_output.csv'
    finref_scores.to_csv(output_file, index=False)

    # Print the first few rows of the dataframe to ensure data is saved
    print(finref_scores.head())
else:
    print("No available data for the specified countries.")