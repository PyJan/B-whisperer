"""this code creates and Azure search index for the embeddings"""

def create_azure_search_index():
    """This function creates and Azure search index for the embeddings. At the beginning we can do that directly in the Azure portal and later automate it."""
    pass