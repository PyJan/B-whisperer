conda create -n aiwhisperers python=3.12
conda activate aiwhisperers
conda install pandas
conda install streamlit
conda install openai
pip install azure-core
pip install azure-search-documents
pip install azure-storage-blob
pip install autogen