from front_end.app import main

if __name__ == "__main__":
    main()