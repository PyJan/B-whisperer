API_BASE="https://genai-openai-aiwhisperers.openai.azure.com"
API_KEY="413127068e6e49baa81b691ccef56911"
API_VERSION="2024-08-01-preview"

config_list = [
  {
    "model": "gpt-4o",
    "api_type": "azure",
    "api_key": API_KEY,
    "base_url": API_BASE,
    "api_version": API_VERSION,
    "temperature": 0.5,
  }
]