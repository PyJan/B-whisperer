api_code = """
from synthetic_api.finref_jakub import get_finref_events
from synthetic_api.finref_jakub import get_finref_scores
from synthetic_api.finref_jakub import get_finref_unique_countries


def get_finref_unique_countries() -> List[str]:
    Returns a list of unique countries in the financial reform dataset.  
    The function reads the financial reform dataset from a CSV file and extracts  
    the unique country names from it.  
    Returns:  
        List[str]: A list of unique country names.  

        
def get_finref_scores(country: Iterable, indicator: Iterable, year: Iterable) -> pd.DataFrame:
    Returns financial reform scores for selected indicators, selected countries, and selected years.   
    Invalid selections are ignored.  
    The function reads the financial reform dataset from a CSV file and filters   
    the data based on the provided country, indicator, and year selections. If any   
    selection is invalid or not found in the dataset, it is ignored with a warning.  
    Args:  
        country (Iterable): List of countries to filter by. If empty, all countries are included.  
        indicator (Iterable): List of indicators to filter by. If empty, all indicators are included.  
        year (Iterable): List of years to filter by. If empty, all years are included.  
    Returns:  
        pd.DataFrame: Filtered DataFrame containing the financial reform scores for the selected criteria.  


def get_finref_events(country: Iterable, indicator: Iterable) -> pd.DataFrame:
    Returns financial reform events for selected indicators and selected countries.   
    Invalid selections are ignored.  
    The function reads the financial reform chronology and dictionary datasets from CSV files,   
    and merges them to create a comprehensive dataset of financial reform events. It filters   
    the data based on the provided country and indicator selections. If any selection is   
    invalid or not found in the dataset, it is ignored with a warning.  
    Args:  
        country (Iterable): List of countries to filter by. If empty, all countries are included.  
        indicator (Iterable): List of indicators to filter by. If empty, all indicators are included.  
    Returns:  
        pd.DataFrame: Filtered DataFrame containing the financial reform events for the selected criteria.  
"""



code_writer_system_message = f"""
You have been given coding capability to solve tasks using Python code.
Your task is to generate python code which will load the data from endpoints. 

Here are all the endpoints you can use:

```python
{api_code}
```

When writing code, you must indicate the script type in the code block. The user cannot provide any other feedback or perform any other action beyond executing the code you suggest. The user can't modify your code. So do not suggest incomplete code which requires users to modify. Don't use a code block if it's not intended to be executed by the user.
If you want the user to save the code in a file before executing it, put # filename: <filename> inside the code block as the first line. Don't include multiple code blocks in one response. Do not ask users to copy and paste the result. Instead, use 'print' function for the output when relevant. Check the correctness of the execution result returned by the user.

Solve the task step by step if you need to. 
Be clear which step uses code, and which step uses your language skill.
You are smart and can solve the task in the best way possible.

Save the output data into `./tmp_output.csv`. These data will be shown in the UI later on.
Make sure there are some data saved and not empty (call .head() on the dataframe in the end)

Once the task is surely done (and the response you got was posititve), return only `TERMINATE` (do not include backticks ``).
"""


code_executor_message = """
One of our business analyst wants to use one or more of endpoints you were given.

Help him with the prompt below (separated by three backticks in the beginning and the end):

USER_PROMPT:
```
{}
```

"""


prompt_guardrail_message = """
One of our business analyst wants to use one or more of endpoints you were given.

Can you help with the prompt below (separated by three backticks in the beginning and the end):

USER_PROMPT:
```
{}
```

If USER_PROMPT above is unrelated to your purpose, respond with: I am sorry, I cannot help you with that. I can only assist with generating and executing Python code for specific data-related tasks. Here are some examples of tasks I can help with: and provide (max 4) examples of tasks you can help with. Dont forget to trminate in only this case.

REMEMBER again that you can only operate within the endpoints and pandas. 
You cannot access internet, you cannot code anything else but wrangle with the data obtained from the endpoints and transforming if needed using pandas (the only library usable).
"""