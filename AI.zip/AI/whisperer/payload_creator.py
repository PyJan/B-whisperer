import glob
from data.sample_prompts.examples import Examples
from data.sample_prompts.parameters import Parameters
from openai import AzureOpenAI


examples = Examples.examples_dict
parameters = Parameters.parameters_dict






def create_payload():
    examples = Examples.examples_dict
    parameters = Parameters.parameters_dict

    apis = glob.glob(r'C:\AI\data\synthetic_api\*.py')
    with open(r'C:\AI\data\synthetic_api\apis_1.txt', 'r') as file:
        system_message_string = file.read()

    for api in apis:
        with open(api, 'r') as file:
            script_content = file.read()
            system_message_string += '\n' +script_content
    runs = glob.glob(r'C:\AI\data\sample_prompts\*.txt')

    for run in runs:
        with open(run, 'r') as file:
            script_content = file.read()
            system_message_string += '\n' + script_content
    payload = {
        "messages": [
            {
                "role": "system",
                "content": [
                    {
                        "type": "text",
                        "text":  system_message_string
                    }
                ]
            },
        ],
        "temperature": parameters["temperature"],
        "top_p":  parameters["top_p"],
        "max_tokens": parameters["max_tokens"]
    }
    for item in examples.items():
        payload['messages'].append({
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": item[0]
                }
            ]
        })
        payload['messages'].append({
            "role": "assistant",
            "content": [
                {
                    "type": "text",
                    "text": item[1]
                }
            ]
        })
    return payload

API_KEY = "413127068e6e49baa81b691ccef56911"
headers = {
    "Content-Type": "application/json",
    "api-key": API_KEY,
}


