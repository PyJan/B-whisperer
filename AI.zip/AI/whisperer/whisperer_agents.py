import os
from pathlib import Path

from autogen import ConversableAgent
from autogen.coding import LocalCommandLineCodeExecutor

from whisperer.credentials import config_list
from whisperer.prompts import prompt_guardrail_message, code_writer_system_message, code_executor_message

work_dir = Path("./data")
work_dir.mkdir(exist_ok=True)

executor = LocalCommandLineCodeExecutor(work_dir=work_dir)

code_executor_agent = ConversableAgent(
    name="code_executor_agent",
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    },
    code_execution_config={
        "executor": executor,
    },
    human_input_mode="NEVER",
    is_termination_msg=lambda msg: "terminate" in msg["content"].lower(),
)

code_writer_agent = ConversableAgent(
    "code_writer",
    system_message=code_writer_system_message,
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    },
    code_execution_config=False,
    max_consecutive_auto_reply=4,
    human_input_mode="NEVER",
    is_termination_msg=lambda msg: "terminate" in msg["content"].lower(),
)

prompt_guardrail_agent = ConversableAgent(
    "prompt_guardrail",
    llm_config={
        "timeout": 600,
        "cache_seed": 42,
        "config_list": config_list,
    },
    code_execution_config=False,
    max_consecutive_auto_reply=1,
    human_input_mode="NEVER",
    is_termination_msg=lambda msg: "python" in msg["content"].lower(),
)



def send_query(user_msg):
    tmp_out = Path('./data/tmp_output.csv')
    if tmp_out.exists():
        os.remove(tmp_out)
    chat_result = prompt_guardrail_agent.initiate_chat(
        code_writer_agent, message=prompt_guardrail_message.format(user_msg))
    if "i am sorry" in chat_result.summary.lower():
        return chat_result
    chat_result = code_executor_agent.initiate_chat(
        code_writer_agent, message=code_executor_message.format(user_msg)
    )
    return chat_result