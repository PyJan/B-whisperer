from openai import AzureOpenAI
from pandas.core.interchange.dataframe_protocol import DataFrame

from whisperer.payload_creator import create_payload

from data.synthetic_api.finref_aigenerated_1 import *
from data.synthetic_api.finref_aigenerated_2 import *
from data.synthetic_api.finref_examples import *
from data.synthetic_api.finref_jakub import  *
from data.synthetic_api.finref_jakub_1 import *
from data.synthetic_api.finref_jakub_2 import *
from data.synthetic_api.finref_jan_1 import *
from data.synthetic_api.finref_petr_1 import *
from data.synthetic_api.finref_petr_2 import *
from data.synthetic_api.finref_petr_3 import *
from data.synthetic_api.finref_petr_4 import *
from data.synthetic_api.finref_samuel_1 import *
from data.synthetic_api.mock_api_1 import *


# Configuration
API_KEY = "413127068e6e49baa81b691ccef56911"
headers = {
    "Content-Type": "application/json",
    "api-key": API_KEY,
}


ENDPOINT = "https://genai-openai-aiwhisperers.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-15-preview"

# Send request
def call_azure(top_p, temperature, query):
    # payload = create_payload(system_message_string)
    # gets the API Key from environment variable AZURE_OPENAI_API_KEY
    client = AzureOpenAI(
        api_version="2024-02-15-preview",
        azure_endpoint="https://genai-openai-aiwhisperers.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-15-preview",
        api_key ="413127068e6e49baa81b691ccef56911"
    )
    payload = create_payload()
    completion = client.chat.completions.create(
        model="gpt-4o",
        messages=payload['messages']+[{
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": query
                }
            ]
        }],
        # messages=payload['messages'] + [{"role": role, message in chat_history.items()}]
        max_tokens=payload['max_tokens'],
        temperature=temperature,
        top_p=top_p,
        # stream=True,
    )
    api = completion.choices[0].message.content
    # Clear markdown formatting
    if api[:9] == "```python":
        api = api[9:]
    if api[-3:] == "```":
        api = api[:-3]
    api = api.strip('\n')
    res = eval(api)
    is_df = False
    if isinstance(res, pd.DataFrame):
        is_df = True
        res.to_csv(r"C:\AI\data\temp_from_completion.csv")
    return (api, res, is_df)


if __name__ == '__main__':
    for i in range(20):
        print(call_azure(0.95, 0.3,'gIVE ME ALL FINANCIAL REFORMS FOR ALBANIA FOR rr INDICATOR'))
