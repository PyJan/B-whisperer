"""streamlit application"""
import os

import pandas
import streamlit as st
import pathlib

from data.synthetic_api.finref_petr_1 import get_deposit_rate
from front_end import constants
from whisperer.prompt_petr import call_azure
from whisperer.whisperer_agents import send_query


class CacheManager:
    """class to manage session state cache and its setup"""

    CACHE_DATA = {
        constants.SELECTED_MODEL: constants.LLMModels.GPT_4_0.value,
        constants.CHAT_HISTORY: [],
        constants.TOP_P: 0.95,
        constants.TEMPERATURE: 0.7,
        constants.COMPLETIONS_BASED: False
    }

    def setup(self):
        for item, value in self.CACHE_DATA.items():
            if item not in st.session_state:
                st.session_state[item] = value


class AIModel:
    """class to encapsulate AI retrieval methods"""

    @staticmethod
    def _agent_based_query(user_input: str):
        return send_query(user_input).summary

    @staticmethod
    def _completions_based_query(top_p, temp, query):
        return call_azure(top_p, temp, query)

    def send_query(self, user_input: str, top_p, temp):
        if st.session_state[constants.COMPLETIONS_BASED]:
            return self._completions_based_query(top_p, temp, user_input)
        return self._agent_based_query(user_input)


class MainApp:
    """main application class

    has method run which is the main entry point to the app
    """

    def __init__(self):
        self.cache_manager = CacheManager()
        self.cache_manager.setup()
        self.model = AIModel()

    @staticmethod
    def _setup_page():
        """setting up page"""
        st.set_page_config(page_title=constants.APP_NAME, page_icon="👌", layout="wide")

    @staticmethod
    def _setup_sidebar():
        """ setting up sidebar"""
        with st.sidebar:
            st.image(image="front_end/Logos/Transparent.png")
            st.title(f"Welcome to {constants.APP_NAME}")
            st.session_state[constants.SELECTED_MODEL] = st.selectbox(
                label="Select model:",
                options=constants.MODEL_NAMES
            )

            st.session_state[constants.COMPLETIONS_BASED] = st.toggle(label="Toggle completions based generation instead of Agent based.", help="Choose either completions based or agent based generation")

            # display configuration options only if completions approach is chosen
            if st.session_state[constants.COMPLETIONS_BASED]:
                with st.expander(label="Configure the model:", expanded=True):
                    st.session_state[constants.TOP_P] = st.slider(
                        label=constants.TOP_P,
                        min_value=0.0,
                        max_value=1.0,
                        value=0.95
                    )
                    st.session_state[constants.TEMPERATURE] = st.slider(
                        label=constants.TEMPERATURE,
                        min_value=0.0,
                        max_value=1.0,
                        value=0.7
                    )
            st.caption("Made by AI-Whisperers :D")

    @staticmethod
    def _setup_header():
        """setting up header"""
        st.title(constants.APP_NAME)

        col1, col2 = st.columns([4, 1])
        with col1:
            # drop down with info
            with st.expander(label="see info"):
                st.write("Info")  # TODO: write info
        with col2:
            st.button(label="clear", type="primary", help="Clear chat history.",
                      on_click=lambda: st.session_state.update({constants.CHAT_HISTORY: []}),
                      use_container_width=True)

    @staticmethod
    def _display_chat_history():
        """display chat history"""
        for role, message in st.session_state[constants.CHAT_HISTORY]:
            with st.chat_message(name=role):
                st.markdown(message)

    def _handle_user_model_interactions(self):
        """handles user model interactions"""
        if user_input := st.chat_input(
                placeholder="Hi Assistant, I want to get financial reform events for  `Czech Rep` I am interested in indicators 'RR' and 'C'. Can you help me with that?"):
            # update chat history with user input
            st.session_state[constants.CHAT_HISTORY].append((constants.USER, user_input))

            # display user input
            with st.chat_message(name=constants.USER):
                st.markdown(user_input)

            # display AI output
            with st.chat_message(name=constants.BOT):
                response = self.model.send_query(
                    user_input,
                    st.session_state[constants.TOP_P],
                    st.session_state[constants.TEMPERATURE]
                )

                # display based on approach
                if st.session_state[constants.COMPLETIONS_BASED]:
                    st.code(response[0])
                    if not response[2]:
                        st.markdown(f"evaluation: {response[1]}")
                    else:
                        path = "data/temp_from_completion.csv"
                        if pathlib.Path(path).exists():
                            with open(path, "r", encoding="utf-8") as f:
                                csv_data = f.read()
                                st.download_button('Download Full Data', data=csv_data, file_name="test.csv")

                                # df preview
                                df = pandas.read_csv(path)
                                st.dataframe(df.head(15))
                else:
                    st.markdown(response)

                # if agent approach then show generated data
                if not st.session_state[constants.COMPLETIONS_BASED]:
                    path = "data/tmp_output.csv"
                    if pathlib.Path(path).exists():
                        with open(path, "r", encoding="utf-8") as f:
                            csv_data = f.read()
                            st.download_button('Download Full Data', data=csv_data, file_name="test.csv")

                            # df preview
                            df = pandas.read_csv(path)
                            st.dataframe(df.head(15))

            # update chat history with AI output
            st.session_state[constants.CHAT_HISTORY].append((constants.BOT, response))

    def run(self):
        self._setup_page()
        self._setup_sidebar()
        self._setup_header()
        self._display_chat_history()
        self._handle_user_model_interactions()


# --- MAIN APP --- #
def main():
    app = MainApp()
    app.run()
