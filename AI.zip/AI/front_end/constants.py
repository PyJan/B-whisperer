"""module to hold constants used in the streamlit app"""
import enum

APP_NAME = "B-Whisperer" # name of our app
CHAT_HISTORY = "chat_history" # key of chat history in session cache
SELECTED_MODEL = "llm-model"
DEFAULT_AI_RESPONSE = "Sorry i am not available right now."
COMPLETIONS_BASED = "completions-based" # agents or completions based... boolean value

# streamlit chat message names
USER = "user"
BOT = "assistant"

@enum.unique
class LLMModels(enum.Enum):
    GPT_4_0 = "gpt-4o"

MODEL_NAMES = [model.value for model in LLMModels] # list of available models names

# model parameters
TEMPERATURE = "temperature"
TOP_P = "top-p"