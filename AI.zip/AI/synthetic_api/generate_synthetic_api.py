"""Code for synthetic api generation"""

import os
import requests

import pandas as pd


def generate_synthetic_api(datasource_name: str,
                           datasource_directory: str,
                           number_calls_to_generate: int = 10,
                           number_rows_to_include: int = 100):
    """This function generates synthetic api for a given data source and saves
    each function in a separate file in data/synthetic_api folder. At the beginning we can
    generate a few sample apis manually"""
    # Prompt
    datasource_path = os.path.join(datasource_directory, datasource_name)

    prompt = f"""Please give me {number_calls_to_generate} API calls about a dataset that is illustrated by the following sample. The dataset is located at "f{datasource_path}".\n\n{pd.read_csv(datasource_path, nrows=number_rows_to_include).to_string(index=False)}"""

    # Configuration
    API_KEY = "413127068e6e49baa81b691ccef56911"
    headers = {
        "Content-Type": "application/json",
        "api-key": API_KEY,
    }

    # Payload for the request
    payload = {
        "messages": [
            {
                "role": "system",
                "content": [
                    {
                        "type": "text",
                        "text": "You are an AI assistant that only creates API calls based on the sample data or summary of the data that the user provides to you along in the prompt. The user may provide more than one dataset. You make sure that you understand what the data is about.\nYou only return immediately executable Python code; you don't put additional formatting on top of it. If the user doesn't ask for API calls, you return a piece of Python code that raises a RuntimeError with a short message. If the user asks for API calls, you return a Python module with an import of modules as the top and then only the API calls. You don't return any additional functions.\nYou make the API call function properly typed (use the typing module for that), you add docstrings to them (include Args and Returns section with typing and include example calls using values in the sample and similar values in the docstring, but only the calls not their output), and you concisely comment the code therein.\nYou load the data in each API call function anew. Assume that the data are in csv form and load directly it using read_csv from the pandas module. You convert columns to numeric before you make any numeric comparisons or doing calculations with these columns, so your code doesn't crash if there are some non-numeric values exceptions.\nYou make only the API call functions that return pandas objects. You give the API calls long descriptive names in snake-case. You are creative when creating the API call function body. You make sure that the call doesn't crash if the inputs are invalid, so you catch the errors.\nYou try to use widely known Python modules, such as pandas or numpy.\nYou prefer making API calls that have parameters."
                    }
                ]
            },
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": prompt
                    }
                ]
            }
        ],
        "temperature": 0.2,
        "top_p": 0.95,
        "max_tokens": 4096
    }

    ENDPOINT = "https://genai-openai-aiwhisperers.openai.azure.com/openai/deployments/gpt-4o/chat/completions?api-version=2024-02-15-preview"

    # Send request
    try:
        response = requests.post(ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()  # Will raise an HTTPError if the HTTP request returned an unsuccessful status code
    except requests.RequestException as e:
        raise SystemExit(f"Failed to make the request. Error: {e}")

    # Extract the response
    synthetic_api = response.json()['choices'][0]['message']['content']

    # Clear markdown formatting
    if synthetic_api[:9] == "```python":
        synthetic_api = synthetic_api[9:]
    if synthetic_api[-3:] == "```":
        synthetic_api = synthetic_api[:-3]

    # Removing possibly incomplete last call
    try:
        exec("def " + synthetic_api.split("def ")[-1])
    except Exception:
        synthetic_api = synthetic_api.replace("def " + synthetic_api.split("def ")[-1], "")

    # Trying to execute
    try:
        exec(synthetic_api)
    except Exception:
        raise SystemExit(f"Failed to parse the response as Python code. Error: {e}")

    return synthetic_api

# print(generate_synthetic_api(datasource_name = "SPX500.csv", datasource_directory = r"C:\Temp\Financial Indicators"))
# print(generate_synthetic_api(datasource_name = "NASDAQ.csv", datasource_directory = r"C:\Temp\Financial Indicators"))


def upload_synthetic_api(datasource_name: str):
    """This function uploads the synthetic api to the Azure storage. At the beginning
    we can do this step manually and later automate it."""
    return None